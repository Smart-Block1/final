
// content_loader.js (Isolated World)
// Responsibilities:
// 1. Check Chrome Storage (Securely)
// 2. Send "ACTIVATE" signal to the Main World script (protected_logic.js) with CONFIG
// 3. Signal Background to set Badge Status

function activate(tier, prefs = {}) {
    // Default to TRUE if undefined (undefined !== false is true)
    const config = {
        enableFs: prefs.masterPower !== false,
        enableCopy: prefs.copyMode !== false
    };

    // ALLOW BOTH PREMIUM AND STANDARD
    if (tier === 'PREMIUM' || tier === 'STANDARD') {
        // 1. Trigger Main World Logic with Config (Enables Fullscreen Block / Copy Enable)
        window.postMessage({ type: "ACTIVATE_GOD_MODE", config: config }, "*");
        
        // 2. Tell Background: "I am active on this tab" (Sets Badge 'ON')
        chrome.runtime.sendMessage({ type: "UPDATE_BADGE", isActive: true }).catch(() => {});
    }
}

// 1. FAST CHECK (On Load)
chrome.storage.local.get(['access_tier', 'masterPower', 'copyMode'], (res) => {
    if (res.access_tier) activate(res.access_tier, res);
});

// 2. LISTENER (For updates from Background)
chrome.runtime.onMessage.addListener((req) => {
    if (req.type === "ACTIVATE_PRO" || req.type === "ACTIVATE_LOCKS") {
        // Re-fetch latest prefs to ensure sync
        chrome.storage.local.get(['access_tier', 'masterPower', 'copyMode'], (res) => {
            if (res.access_tier) activate(res.access_tier, res);
        });
    }
});

// 3. STORAGE LISTENER (For silent background/popup updates)
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
        // If Tier, Power, or Copy settings change, re-evaluate
        if (changes.access_tier || changes.masterPower || changes.copyMode) {
             chrome.storage.local.get(['access_tier', 'masterPower', 'copyMode'], (res) => {
                if (res.access_tier) activate(res.access_tier, res);
            });
        }
    }
});

// 4. BRIDGE: Extension Status to Webpage (Optional)
window.addEventListener("message", (e) => {
    if(e.data && e.data.type === "EXT_STAT") {
        // Forwarding logic if needed
    }
});
