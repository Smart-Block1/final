
// content_loader.js (Isolated World)
// Responsibilities:
// 1. Check Chrome Storage (Securely)
// 2. Send "ACTIVATE" signal to the Main World script (protected_logic.js) with CONFIG
// 3. Listen for Storage Changes (Toggle switches) and update Main World instantly

function updateEnforcer(tier, prefs) {
    // Default to TRUE if undefined
    const config = {
        enableFs: prefs.masterPower !== false,
        enableCopy: prefs.copyMode !== false
    };

    if (tier === 'PREMIUM' || tier === 'STANDARD') {
        // 1. Send Config to Main World (protected_logic.js)
        window.postMessage({ type: "ACTIVATE_GOD_MODE", config: config }, "*");
        
        // 2. Set Badge
        chrome.runtime.sendMessage({ type: "UPDATE_BADGE", isActive: true }).catch(() => {});
    }
}

// 1. INITIAL LOAD
chrome.storage.local.get(['access_tier', 'masterPower', 'copyMode'], (res) => {
    if (res.access_tier) {
        updateEnforcer(res.access_tier, res);
    }
});

// 2. LISTEN FOR TOGGLE SWITCHES (Real-time updates)
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
        // If critical settings change, re-fetch everything and update
        if (changes.masterPower || changes.copyMode || changes.access_tier) {
             chrome.storage.local.get(['access_tier', 'masterPower', 'copyMode'], (res) => {
                if (res.access_tier) {
                    updateEnforcer(res.access_tier, res);
                }
            });
        }
    }
});

// 3. LISTEN FOR BACKGROUND SIGNALS
chrome.runtime.onMessage.addListener((req) => {
    if (req.type === "ACTIVATE_PRO" || req.type === "ACTIVATE_LOCKS") {
        chrome.storage.local.get(['access_tier', 'masterPower', 'copyMode'], (res) => {
            if (res.access_tier) updateEnforcer(res.access_tier, res);
        });
    }
});
