
// ============================================
// 🧠 SMART TEST PRO - FLOATING AI WIDGET
// ============================================

(function() {
    const HOST_ID = "st-overlay-host";
    
    // WAIT FOR BODY
    const waitForBody = setInterval(() => {
        if (document.body) {
            clearInterval(waitForBody);
            checkAndStart();
        }
    }, 50);

    // NOTE: Removed insecure 'START_ISLAND_AI' listener. 
    // The overlay now relies strictly on secure storage checks.

    function checkAndStart() {
        chrome.storage.local.get(['access_tier', 'aiMode'], (res) => {
            // STRICT CHECK: Only PREMIUM accounts can see the AI
            const isPremium = res.access_tier === 'PREMIUM';
            const isEnabled = res.aiMode !== false; 

            if (isPremium && isEnabled) {
                chrome.runtime.sendMessage({ type: "GET_TAB_ID" }, (response) => {
                    if (response && response.tabId) {
                        initOverlay(response.tabId);
                    }
                });
            } else {
                // If downgraded or disabled, remove UI immediately
                const el = document.getElementById(HOST_ID);
                if (el) el.remove();
            }
        });
    }

    // LISTENER: Inject immediately if upgraded or Toggled ON/OFF
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local') {
            if (changes.access_tier || changes.aiMode) {
                checkAndStart();
            }
        }
    });

    function initOverlay(TAB_ID) {
        if (document.getElementById(HOST_ID)) return;

        const STATE_KEY = `aiState_${TAB_ID}`;
        const RESULT_KEY = `aiResult_${TAB_ID}`;
        const INPUT_KEY = `aiInput_${TAB_ID}`;

        const host = document.createElement('div');
        host.id = HOST_ID;
        host.setAttribute('data-ext-ui', 'true'); // Whitelist for Force Copy
        host.style.cssText = "position: fixed; top: 0; left: 0; width: 0; height: 0; z-index: 2147483647; pointer-events: none;";
        document.body.appendChild(host);

        const shadow = host.attachShadow({ mode: 'open' });

        shadow.innerHTML = `
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap');
                * { box-sizing: border-box; user-select: none; }
                
                .widget {
                    position: fixed;
                    top: 50px; right: 50px;
                    width: 340px; height: 550px;
                    min-width: 280px; min-height: 200px;
                    background: rgba(255, 255, 255, 0.15);
                    backdrop-filter: blur(15px);
                    -webkit-backdrop-filter: blur(15px);
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    border-radius: 16px;
                    box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.2);
                    color: #1e293b;
                    font-family: 'Inter', sans-serif;
                    display: flex; flex-direction: column;
                    pointer-events: auto;
                    transition: opacity 0.1s ease-in-out, height 0.2s ease;
                }
                .widget.hide { display: none !important; }
                
                /* Minimized State */
                .widget.minimized {
                    height: 48px !important;
                    min-height: 0 !important;
                    overflow: hidden;
                    resize: none;
                }
                .widget.minimized .content { display: none; }
                .widget.minimized .resize-handle { display: none; }
                
                .header {
                    padding: 12px 16px; background: rgba(255,255,255,0.2);
                    font-weight: 800; color: #1e40af; font-size: 13px;
                    display: flex; align-items: center; cursor: grab;
                    border-bottom: 1px solid rgba(255,255,255,0.2);
                    height: 48px;
                }
                .header:active { cursor: grabbing; }

                .content { padding: 16px; display: flex; flex-direction: column; flex: 1; gap: 12px; overflow: hidden; position: relative; }
                
                .input-area {
                    display: flex; flex-direction: column; gap: 8px;
                }

                .manual-input {
                    width: 100%; height: 60px;
                    background: rgba(255,255,255,0.4);
                    border: 1px solid rgba(255,255,255,0.5);
                    border-radius: 8px; padding: 8px;
                    font-size: 12px; color: #0f172a; resize: none; outline: none;
                    user-select: text !important;
                }
                .manual-input:focus { background: rgba(255,255,255,0.7); border-color: #3b82f6; }
                
                .img-preview {
                    position: relative;
                    background: rgba(0,0,0,0.1);
                    padding: 6px;
                    border-radius: 8px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    border: 1px dashed rgba(255,255,255,0.4);
                }
                .img-preview.hide { display: none; }
                .img-preview img {
                    max-height: 100px;
                    max-width: 100%;
                    border-radius: 4px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }
                .img-remove {
                    position: absolute; top: -8px; right: -8px;
                    background: #ef4444; color: white;
                    width: 20px; height: 20px;
                    border-radius: 50%;
                    text-align: center; line-height: 20px;
                    font-size: 12px; cursor: pointer;
                    font-weight: bold;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                }
                .img-remove:hover { background: #dc2626; }

                .btn-row { display: flex; gap: 8px; }
                .btn {
                    flex: 1; padding: 10px; border-radius: 8px;
                    color: white; font-weight: 700; font-size: 12px;
                    cursor: pointer; border: 1px solid rgba(255,255,255,0.2);
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                }
                .btn-text { background: linear-gradient(135deg, #4f46e5, #4338ca); }
                .btn-scan { background: linear-gradient(135deg, #2563eb, #1d4ed8); }
                .btn:hover { transform: translateY(-1px); filter: brightness(1.1); }
                
                .result-box {
                    background: rgba(255,255,255,0.05);
                    border: 1px solid rgba(255,255,255,0.1);
                    border-radius: 8px; padding: 12px;
                    flex: 1; overflow-y: auto; font-size: 13px;
                    color: #0f172a; line-height: 1.5; font-weight: 500;
                    user-select: text !important;
                }
                .hint { font-size: 10px; text-align: center; color: #334155; margin-top: 5px; opacity: 0.8; }
                
                .resize-handle {
                    position: absolute; bottom: 0; right: 0; width: 16px; height: 16px;
                    cursor: nwse-resize; z-index: 50;
                    background: linear-gradient(135deg, transparent 50%, rgba(255,255,255,0.5) 50%);
                    border-bottom-right-radius: 15px;
                    transition: background 0.2s;
                }
                .resize-handle:hover {
                    background: linear-gradient(135deg, transparent 50%, #3b82f6 50%);
                }
                
                .control-btn {
                    cursor: pointer; font-weight: bold; padding: 0 6px;
                    opacity: 0.7; transition: opacity 0.2s;
                }
                .control-btn:hover { opacity: 1; }
            </style>

            <div class="widget" id="ui">
                <div class="header" id="dragHandle">
                    <span style="margin-right:8px; opacity:0.5;">⋮⋮</span>
                    <span style="flex:1;">AI ASSISTANT</span>
                    
                    <!-- Min Button -->
                    <span id="btnMin" class="control-btn" style="font-size:18px; line-height:10px; margin-right:4px;" title="Minimize">_</span>
                    
                    <!-- Close Button -->
                    <span id="btnHide" class="control-btn" style="color:#ef4444; font-size:16px;" title="Hide (Press / to show)">✕</span>
                </div>
                <div class="content">
                    <div class="input-area">
                        <div id="imgPreview" class="img-preview hide">
                            <img id="pastedImgSrc" />
                            <div id="btnRemoveImg" class="img-remove">✕</div>
                        </div>
                        <textarea class="manual-input" id="inpManual" placeholder="Paste text or image here..."></textarea>
                    </div>
                    <div class="btn-row">
                        <button class="btn btn-text" id="btnSendText">ASK AI</button>
                        <button class="btn btn-scan" id="btnScanPage">SCAN PAGE</button>
                    </div>
                    <div class="result-box" id="output">
                        <div style="text-align:center; padding-top:40px; color:#475569;">Ready.</div>
                    </div>
                    <div class="hint">Press <strong>/</strong> to Toggle</div>
                    <div class="resize-handle" id="resizeHandle"></div>
                </div>
            </div>
        `;

        const ui = shadow.getElementById('ui');
        const header = shadow.getElementById('dragHandle');
        const btnSendText = shadow.getElementById('btnSendText');
        const btnScanPage = shadow.getElementById('btnScanPage');
        const output = shadow.getElementById('output');
        const inpManual = shadow.getElementById('inpManual');
        const btnHide = shadow.getElementById('btnHide');
        const btnMin = shadow.getElementById('btnMin');
        const resizeHandle = shadow.getElementById('resizeHandle');
        
        // Image Elements
        const imgPreview = shadow.getElementById('imgPreview');
        const pastedImgSrc = shadow.getElementById('pastedImgSrc');
        const btnRemoveImg = shadow.getElementById('btnRemoveImg');

        let lastState = "";
        let currentImageBase64 = null;

        // PERSISTENCE: LOAD INPUT
        chrome.storage.local.get(INPUT_KEY, (d) => {
            if(d[INPUT_KEY]) inpManual.value = d[INPUT_KEY];
        });

        // PERSISTENCE: SAVE INPUT
        inpManual.addEventListener('input', () => {
            chrome.storage.local.set({ [INPUT_KEY]: inpManual.value });
        });

        // PASTE LISTENER FOR IMAGES
        inpManual.addEventListener('paste', (e) => {
            const clipboard = e.clipboardData || (e.originalEvent && e.originalEvent.clipboardData) || window.clipboardData;
            if (!clipboard || !clipboard.items) return;

            const items = clipboard.items;
            for (let i = 0; i < items.length; i++) {
                if (items[i].type.indexOf('image') !== -1) {
                    e.preventDefault(); // Stop text insertion of filename/dummy text
                    const blob = items[i].getAsFile();
                    const reader = new FileReader();
                    reader.onload = (event) => {
                        const b64 = event.target.result;
                        currentImageBase64 = b64.split(',')[1]; // Remove data:image/png;base64,
                        pastedImgSrc.src = b64;
                        imgPreview.classList.remove('hide');
                        btnSendText.textContent = "ANALYZE IMAGE";
                        // Clear text input if it was empty or user just wants to send image
                        if (!inpManual.value.trim()) inpManual.value = "";
                    };
                    reader.readAsDataURL(blob);
                    return; // Take first image only
                }
            }
        });

        btnRemoveImg.onclick = () => {
            currentImageBase64 = null;
            pastedImgSrc.src = "";
            imgPreview.classList.add('hide');
            btnSendText.textContent = "ASK AI";
        };

        // Prevent scrolling propagation
        output.addEventListener('wheel', e => e.stopPropagation(), {passive:false});
        
        // Prevent key propagation from input
        inpManual.addEventListener('keydown', e => e.stopPropagation());

        chrome.runtime.onMessage.addListener((msg) => {
            if (msg.type === "PREP_CAPTURE") ui.style.opacity = '0'; 
            else if (msg.type === "POST_CAPTURE") ui.style.opacity = '1'; 
        });

        chrome.storage.onChanged.addListener((changes, area) => {
            if (area === 'local' && (changes[STATE_KEY] || changes[RESULT_KEY])) {
                chrome.storage.local.get([STATE_KEY, RESULT_KEY], (d) => updateUI(d[STATE_KEY], d[RESULT_KEY]));
            }
        });

        // --- DRAG LOGIC ---
        let isDrag = false, startX, startY, initL, initT;
        header.addEventListener('mousedown', e => {
            if(e.target === btnHide || e.target === btnMin) return;
            isDrag = true; startX = e.clientX; startY = e.clientY;
            const r = ui.getBoundingClientRect(); initL = r.left; initT = r.top;
            header.style.cursor = 'grabbing'; e.preventDefault();
        });
        
        // --- RESIZE LOGIC ---
        let isResize = false, startW, startH;
        resizeHandle.addEventListener('mousedown', e => {
            isResize = true; 
            startX = e.clientX; startY = e.clientY;
            startW = ui.offsetWidth; startH = ui.offsetHeight;
            e.preventDefault(); e.stopPropagation();
        });

        document.addEventListener('mousemove', e => {
            if (isDrag) {
                ui.style.left = (initL + e.clientX - startX) + 'px';
                ui.style.top = (initT + e.clientY - startY) + 'px';
            } else if (isResize) {
                const newW = startW + (e.clientX - startX);
                const newH = startH + (e.clientY - startY);
                ui.style.width = newW + 'px';
                ui.style.height = newH + 'px';
            }
        });

        document.addEventListener('mouseup', () => { 
            isDrag = false; 
            isResize = false; 
            header.style.cursor = 'grab'; 
        });

        // --- MINIMIZE LOGIC ---
        const toggleMinimize = (e) => {
            if(e) e.stopPropagation();
            ui.classList.toggle('minimized');
        };
        btnMin.onclick = toggleMinimize;
        header.addEventListener('dblclick', toggleMinimize);

        // --- GLOBAL TOGGLE SHORTCUT ---
        document.addEventListener('keydown', e => {
            if (e.repeat) return; 
            if (e.ctrlKey || e.altKey || e.metaKey) return;
            
            const tag = e.target.tagName;
            if (['INPUT','TEXTAREA','SELECT'].includes(tag) || e.target.isContentEditable) return;
            if (e.target === host) return;

            if (e.key === '/') { 
                e.preventDefault(); 
                e.stopImmediatePropagation(); 
                ui.classList.toggle('hide'); 
            }
        }, true);

        btnHide.onclick = () => ui.classList.add('hide');

        // --- APP LOGIC ---
        btnSendText.onclick = () => {
            const txt = inpManual.value.trim();
            // Allow sending if Text OR Image is present
            if(!txt && !currentImageBase64) { 
                output.innerHTML = "<div style='color:#ef4444'>Enter text or paste an image.</div>"; 
                return; 
            }
            send(txt, currentImageBase64);
        };
        btnScanPage.onclick = () => send(null, null);

        function send(txt, img) {
            chrome.runtime.sendMessage({ 
                type: "AI_SCAN_START", 
                tabId: TAB_ID, 
                manualText: txt,
                manualImage: img 
            });

            if (lastState !== 'SCANNING') {
                output.innerHTML = "<div style='text-align:center; padding-top:40px; color:#1e40af; font-weight:bold;'>Thinking...</div>";
                setLoading(true);
            }
        }

        function setLoading(bool) {
            btnSendText.disabled = bool;
            btnScanPage.disabled = bool;
            if(bool) {
                btnSendText.textContent = "...";
                btnScanPage.textContent = "...";
            } else {
                btnSendText.textContent = currentImageBase64 ? "ANALYZE IMAGE" : "ASK AI";
                btnScanPage.textContent = "SCAN PAGE";
            }
        }

        function updateUI(st, res) {
            if (st === lastState && st === 'SCANNING') return;
            lastState = st;
            if(!st) return;
            
            if(st === 'SCANNING') {
                setLoading(true);
            } else if(st === 'COMPLETED') {
                setLoading(false);
                output.innerHTML = formatAI(res);
            } else if(st === 'ERROR') {
                setLoading(false);
                output.innerHTML = `<div style='color:#ef4444'>Error: ${res}</div>`;
            }
        }

        function formatAI(txt) {
            if(!txt) return "";
            return txt
                .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                .replace(/\*\*(Question \d+:?)\*\*/gi, '<div style="margin-top:10px; color:#1e40af; font-weight:800; border-bottom:1px solid #ddd;">$1</div>')
                .replace(/\*\*(Answer:?)\*\*/gi, '<span style="color:#166534; font-weight:800; margin-right:4px;">$1</span>')
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\n/g, '<br>');
        }
    }
})();
