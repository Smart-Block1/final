// FILE: supabase/functions/analyze-content/index.ts

import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // 1. CORS Preflight (За да работи от браузъра)
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { text } = await req.json()

    // 2. Проверка за потребителски токен
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('Липсва авторизация (Login required)')
    }

    // 3. Свързване с базата данни (Admin Mode)
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // 4. Проверка кой е потребителят
    const { data: { user }, error: userError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (userError || !user) throw new Error('Невалиден потребител')

    // 5. ИЗВЛИЧАНЕ НА ДАННИ ОТ БАЗАТА (Лиценз + Ключ)
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('access_tier, gemini_key')
      .eq('id', user.id)
      .single()

    if (profileError || !profile) {
        throw new Error('Профилът не е намерен.')
    }

    // --- ЗАЩИТА 1: Проверка за Платен Лиценз ---
    if (profile.access_tier !== 'PREMIUM') {
      return new Response(JSON.stringify({ error: 'Изисква се PREMIUM лиценз за да ползвате AI функциите.' }), {
        status: 403, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    // --- ЗАЩИТА 2: Проверка за наличен Gemini API Ключ ---
    if (!profile.gemini_key || profile.gemini_key.trim() === "") {
        return new Response(JSON.stringify({ error: 'Липсва API ключ. Моля добавете го в настройките на разширението.' }), {
         status: 400, 
         headers: { ...corsHeaders, 'Content-Type': 'application/json' }
       })
    }

    // 6. ВИКАНЕ НА GOOGLE GEMINI (С твоя таен промпт)
    const userApiKey = profile.gemini_key;
    
    const geminiResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${userApiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `
            SYSTEM INSTRUCTION: You are SmartBlock AI. 
            TASK: Identify the core question in the user's text and provide the DIRECT answer only.
            RULES:
            - If multiple choice, output ONLY the correct letter/option.
            - Keep it under 50 words.
            - Do not explain yourself.
            
            USER INPUT: "${text}"
            ` 
          }]
        }]
      })
    })

    const geminiData = await geminiResponse.json()

    // Проверка за грешка от Google (напр. грешен ключ)
    if (geminiData.error) {
        return new Response(JSON.stringify({ error: 'Вашият API ключ е невалиден (Google Error).' }), {
            status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        })
    }

    const answer = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || "Не мога да намеря отговор."

    // 7. ВРЪЩАНЕ НА ОТГОВОРА
    return new Response(JSON.stringify({ answer: answer }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})