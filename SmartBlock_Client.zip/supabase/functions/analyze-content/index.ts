
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"
import { GoogleGenAI } from "https://esm.sh/@google/genai"

declare const Deno: any;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // 1. Handle CORS Preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // 2. Initialize Supabase Client with Auth Header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('Missing Authorization header')
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )

    // 3. Verify User
    const {
      data: { user },
      error: userError,
    } = await supabaseClient.auth.getUser()

    if (userError || !user) {
      throw new Error('Invalid User Token')
    }

    // 4. Check Access Tier (IGNORE user_pass column for privacy)
    // We strictly select only what we need: 'access_tier'
    const { data: profile, error: profileError } = await supabaseClient
      .from('profiles')
      .select('access_tier') 
      .eq('id', user.id)
      .single()

    if (profileError || !profile) {
      throw new Error('Profile retrieval failed')
    }

    // 5. Enforce Premium License
    if (profile.access_tier !== 'PREMIUM') {
       return new Response(
        JSON.stringify({ error: 'Access Denied: Premium License Required.' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 403 }
      )
    }

    // 6. Parse Input
    const { text, manualText, manualImage } = await req.json()
    const prompt = manualText || text

    if (!prompt && !manualImage) {
        throw new Error('No content provided')
    }

    // 7. Initialize Gemini
    const apiKey = Deno.env.get('GEMINI_API_KEY') || Deno.env.get('API_KEY');
    if (!apiKey) throw new Error('Server Config Error: Missing API Key');

    const ai = new GoogleGenAI({ apiKey: apiKey });

    let responseText = "";

    // 8. Generate Content
    if (manualImage) {
        // Multimodal Request
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/png', data: manualImage } },
                    { text: prompt || "Analyze this image and explain the contents." }
                ]
            }
        });
        responseText = response.text;
    } else {
        // Text Request
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt
        });
        responseText = response.text;
    }

    // 9. Return Result
    return new Response(
      JSON.stringify({ answer: responseText }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    )
  }
})
