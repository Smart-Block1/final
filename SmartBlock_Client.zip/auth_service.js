
const SUPABASE_URL = "https://akfwepxzzupenttuiaog.supabase.co";
const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFrZndlcHh6enVwZW50dHVpYW9nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjYxMTg4ODYsImV4cCI6MjA4MTY5NDg4Nn0.ZgofhCY5jU5jVsBEszWgzTina4bIxgpbaRM-jR7VHb0";

export const AuthService = {
    async signUp(email, password, fullName) {
        // This redirect URL must match the one configured in Supabase Auth settings
        const redirectUrl = chrome.runtime.getURL("success.html");

        const res = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
            method: 'POST',
            headers: { 
                'apikey': ANON_KEY, 
                'Content-Type': 'application/json' 
            },
            body: JSON.stringify({ 
                email, 
                password,
                options: {
                    emailRedirectTo: redirectUrl,
                    data: { full_name: fullName } // Metadata for the profile
                }
            })
        });
        
        const data = await res.json();
        
        if (!res.ok) {
            throw new Error(data.msg || data.message || "Signup failed");
        }

        // If auto-login happens (session exists), sanitize first
        if (data.session) {
            await this.clearLocalLicenseData();
            
            // NEW: Ensure profile is initialized as NONE immediately
            try {
                await this.ensureProfile(data.user.id, data.user.email, data.session.access_token, fullName);
            } catch(e) { console.warn("Signup profile init error", e); }

            await chrome.storage.local.set({ 
                session: data.session.access_token, 
                user: data.user,
                userId: data.user.id
            });
        }
        
        return data;
    },

    async login(email, password) {
        // 1. Authenticate with Supabase
        const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
            method: 'POST',
            headers: { 'apikey': ANON_KEY, 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error_description || data.message || "Invalid email or password");
        
        // 2. Ensure Profile Exists
        try {
            await this.ensureProfile(data.user.id, data.user.email, data.access_token);
        } catch (err) {
            console.warn("Profile sync warning:", err);
        }
        
        // 3. SANITIZE: Wipe previous user's license data BEFORE saving new session
        await this.clearLocalLicenseData();

        // 4. Save New Session
        await chrome.storage.local.set({ 
            session: data.access_token, 
            user: data.user,
            userId: data.user.id
        });
        return data;
    },

    // Helper to prevent "Ghost Permissions" from previous accounts
    async clearLocalLicenseData() {
        await chrome.storage.local.remove([
            'access_tier', 
            'active_license_key', 
            'license_expiry', 
            'notes', 
            'geminiKeys'
        ]);
    },

    async resendConfirmationEmail(email) {
        const redirectUrl = chrome.runtime.getURL("success.html");
        const res = await fetch(`${SUPABASE_URL}/auth/v1/resend`, {
            method: 'POST',
            headers: { 'apikey': ANON_KEY, 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                email, 
                type: 'signup',
                options: { emailRedirectTo: redirectUrl }
            })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.msg || data.error_description || data.message || "Resend failed");
        return data;
    },

    async getUser(token) {
        const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
            method: 'GET',
            headers: { 
                'apikey': ANON_KEY, 
                'Authorization': `Bearer ${token}` 
            }
        });
        if(!res.ok) throw new Error("Invalid Token");
        return await res.json();
    },

    async ensureProfile(uid, email, token, fullName = null) {
        const check = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${uid}`, {
            method: 'GET',
            headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${token}` }
        });
        
        const existing = await check.json();
        
        if (!existing || existing.length === 0) {
            const bodyData = { 
                id: uid, 
                email: email, 
                access_tier: 'NONE' // STRICT DEFAULT FOR NEW USERS
            };
            if (fullName) bodyData.full_name = fullName;

            await fetch(`${SUPABASE_URL}/rest/v1/profiles`, {
                method: 'POST',
                headers: { 
                    'apikey': ANON_KEY, 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                    'Prefer': 'resolution=ignore-duplicates'
                },
                body: JSON.stringify(bodyData)
            });
        }
    },

    async logout() {
        await chrome.storage.local.remove([
            'session', 'user', 'userId', 
            'geminiKeys', 'notes', 'access_tier', 
            'active_license_key', 'license_expiry'
        ]);
    },

    async getSession() {
        const res = await chrome.storage.local.get(['session', 'user']);
        return (res.session && res.user) ? res : null;
    }
};
