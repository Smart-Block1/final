
// dynamic_scanner.js
(function() {
    let hasRun = false;

    // Wait for DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initScanner);
    } else {
        initScanner();
    }

    async function initScanner() {
        if (hasRun) return;
        hasRun = true;

        // 1. Get Config & Access Tier
        const storage = await chrome.storage.local.get(['geminiKeys', 'notes', 'access_tier']);
        
        // STRICT CHECK: Must be PREMIUM to run
        if (storage.access_tier !== 'PREMIUM') return;
        
        if (!storage.geminiKeys || storage.geminiKeys.length === 0) return;

        const notes = storage.notes || "";
        
        // 2. Parse Notes for CSS Selectors
        const cssMatch = notes.match(/CSS:\s*([^\n]+)/);
        
        if (cssMatch && cssMatch[1]) {
            const selector = cssMatch[1].trim();
            console.log("Smart Block PRO: Dynamic Selector Found:", selector);
            scanAndHighlight(selector);
        }
    }

    function scanAndHighlight(selector) {
        const elements = document.querySelectorAll(selector);
        if (elements.length === 0) return;

        const style = document.createElement('style');
        style.textContent = `
            .sb-tooltip-trigger {
                position: relative;
                border-left: 3px solid #3b82f6 !important;
                cursor: help;
            }
            .sb-tooltip {
                position: absolute;
                bottom: 100%;
                left: 0;
                background: #1e293b;
                color: #fff;
                padding: 8px 12px;
                border-radius: 6px;
                font-family: sans-serif;
                font-size: 12px;
                width: 250px;
                box-shadow: 0 4px 6px rgba(0,0,0,0.2);
                z-index: 999999;
                pointer-events: none;
                opacity: 0;
                transition: opacity 0.2s;
                margin-bottom: 8px;
            }
            .sb-tooltip::after {
                content: '';
                position: absolute;
                top: 100%;
                left: 10px;
                border-width: 5px;
                border-style: solid;
                border-color: #1e293b transparent transparent transparent;
            }
            .sb-tooltip-trigger:hover .sb-tooltip {
                opacity: 1;
            }
        `;
        document.head.appendChild(style);

        elements.forEach((el, index) => {
            el.classList.add('sb-tooltip-trigger');
            
            const tip = document.createElement('div');
            tip.className = 'sb-tooltip';
            tip.textContent = "Analyzing...";
            el.appendChild(tip);

            // 3. Send to Background
            setTimeout(() => {
                const textContext = el.innerText.substring(0, 1000); 
                
                chrome.runtime.sendMessage({
                    type: "AI_FETCH_DIRECT",
                    text: textContext
                }, (response) => {
                    if (response && response.success) {
                        let ans = response.answer.replace(/\*\*Answer:?\*\*/i, '').trim();
                        ans = ans.replace(/\*\*Question.*?\*\*/, '').trim(); 
                        
                        tip.innerHTML = `<strong style="color:#4ade80">AI Suggestion:</strong><br>${ans}`;
                    } else {
                        // Silent fail or update tooltip
                        tip.textContent = response.error || "Analysis failed.";
                    }
                });
            }, index * 500); 
        });
    }
})();
