
// dynamic_scanner.js - STRICT PREMIUM POINT & SHOOT
// 1. Checks access_tier === 'PREMIUM' immediately.
// 2. Uses Alt + S to trigger analysis on element under cursor.
// 3. Uses Shadow DOM UI for results.

(function() {
    const EDGE_FUNCTION_URL = "https://akfwepxzzupenttuiaog.supabase.co/functions/v1/analyze-content";
    const HOST_ID = "sb-shadow-host";
    let currentElement = null;

    // 1. STARTUP
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    async function init() {
        // --- STRICT PREMIUM CHECK ---
        const storage = await chrome.storage.local.get(['access_tier', 'session']);
        
        if (storage.access_tier !== 'PREMIUM') {
            // console.log("Smart Block: AI disabled (Standard Plan)");
            return; // STOP. NO AI FOR FREE/STANDARD.
        }

        // console.log("Smart Block: PREMIUM AI Ready (Alt+S to Scan)");

        // 2. TRACK MOUSE (For Point & Shoot)
        document.addEventListener('mousemove', (e) => {
            currentElement = e.target;
        }, { passive: true });

        // 3. KEY BINDING (Alt + S)
        document.addEventListener('keydown', (e) => {
            if (e.altKey && (e.key === 's' || e.key === 'S')) {
                e.preventDefault();
                e.stopImmediatePropagation();
                triggerAI(storage.session);
            }
        });
    }

    async function triggerAI(sessionToken) {
        if (!currentElement) return;

        // Extract Text
        let text = currentElement.innerText.trim();
        // If text is too short, try parent
        if (text.length < 5 && currentElement.parentElement) {
            text = currentElement.parentElement.innerText.trim();
        }

        if (text.length < 2) return;

        // Visual Feedback
        highlight(currentElement);

        // Calculate Position
        const rect = currentElement.getBoundingClientRect();
        const x = rect.left;
        const y = rect.bottom;

        // Show "Thinking..."
        showTooltip(x, y, "🧠 Analyzing...", true);

        // Prepare Token
        let token = null;
        if (sessionToken) {
            token = (typeof sessionToken === 'object') ? sessionToken.access_token : sessionToken;
        }

        if (!token) {
            showTooltip(x, y, "⚠️ Login Error", false, true);
            return;
        }

        // Send Request
        try {
            const res = await fetch(EDGE_FUNCTION_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ text: text })
            });

            const data = await res.json();
            
            if (!res.ok) {
                showTooltip(x, y, "Error: " + (data.error || "Access Denied"), false, true);
            } else {
                showTooltip(x, y, data.answer, false);
            }

        } catch (err) {
            showTooltip(x, y, "Network Error", false, true);
        }
    }

    function highlight(el) {
        const orig = el.style.backgroundColor;
        const origTrans = el.style.transition;
        
        el.style.transition = "background-color 0.2s ease";
        el.style.backgroundColor = "rgba(59, 130, 246, 0.2)"; // Blue tint
        
        setTimeout(() => {
            el.style.backgroundColor = orig;
            setTimeout(() => { el.style.transition = origTrans; }, 200);
        }, 300);
    }

    // --- UI LOGIC (Shadow DOM) ---
    function ensureHost() {
        let host = document.getElementById(HOST_ID);
        if (!host) {
            host = document.createElement('div');
            host.id = HOST_ID;
            host.setAttribute('data-ext-ui', 'true');
            host.style.cssText = "position: fixed; top: 0; left: 0; width: 0; height: 0; z-index: 2147483647; pointer-events: none; display: block;";
            (document.documentElement || document.body).appendChild(host);
            
            const shadow = host.attachShadow({ mode: 'open' });
            const style = document.createElement('style');
            style.textContent = `
                :host { all: initial; font-family: sans-serif; }
                .sb-tooltip {
                    position: fixed;
                    z-index: 2147483647;
                    background: #0f172a;
                    color: #f8fafc;
                    padding: 12px 16px;
                    border-radius: 8px;
                    border: 1px solid #334155;
                    font-size: 13px;
                    line-height: 1.5;
                    box-shadow: 0 10px 25px rgba(0,0,0,0.5);
                    max-width: 350px;
                    min-width: 150px;
                    pointer-events: auto;
                    display: flex; flex-direction: column; gap: 8px;
                    animation: fadeIn 0.2s ease-out;
                }
                @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
                .spinner {
                    width: 14px; height: 14px;
                    border: 2px solid #60a5fa; border-bottom-color: transparent;
                    border-radius: 50%; animation: spin 0.8s linear infinite;
                    display: inline-block; margin-right: 8px;
                }
                @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
                .close {
                    position: absolute; top: -8px; right: -8px;
                    width: 22px; height: 22px; background: #ef4444; color: white;
                    border-radius: 50%; cursor: pointer;
                    display: flex; align-items: center; justify-content: center;
                    font-weight: bold; font-size: 14px;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.3);
                }
                .close:hover { background: #dc2626; }
                strong { color: #60a5fa; }
            `;
            shadow.appendChild(style);
        }
        return host;
    }

    function showTooltip(x, y, content, isLoading, isError) {
        const host = ensureHost();
        const shadow = host.shadowRoot;
        
        // Remove old tooltips
        const old = shadow.querySelector('.sb-tooltip');
        if (old) old.remove();

        const div = document.createElement('div');
        div.className = 'sb-tooltip';

        // Viewport constraints
        const pad = 20;
        if (x + 350 > window.innerWidth) x = window.innerWidth - 370;
        if (y + 200 > window.innerHeight) y = y - 220;
        if (x < pad) x = pad;
        if (y < pad) y = pad;

        div.style.left = `${x}px`;
        div.style.top = `${y + 10}px`;

        if (isLoading) {
            div.innerHTML = `<div><span class="spinner"></span> ${content}</div>`;
        } else {
            const cleanText = (content || "").replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
            div.innerHTML = `
                <div class="close">×</div>
                <div style="font-family: 'Segoe UI', sans-serif;">${cleanText}</div>
            `;
            div.querySelector('.close').onclick = (e) => {
                e.stopPropagation();
                div.remove();
            };
        }

        if (isError) {
            div.style.borderColor = '#ef4444';
            div.style.color = '#fca5a5';
        }

        shadow.appendChild(div);
    }

})();
