
/**
 * ⛔ WARNING: PROPRIETARY CODE
 * Copyright (c) 2025 Smart Block Pro. All Rights Reserved.
 * * UNAUTHORIZED COPYING, REVERSE ENGINEERING, OR DISTRIBUTION 
 * OF THIS SOFTWARE IS STRICTLY PROHIBITED AND WILL BE PROSECUTED.
 * * This code contains digital watermarks that track unauthorized usage.
 * Tracking ID: SB-TRACK-UserLogin-Active
 */

// protected_logic.js (Main World - Native Injection)
(function() {
    // ANTI-TAMPER PROTECTION
    setInterval(() => {
        const start = new Date().getTime();
        debugger; // This stops the code if DevTools is open
        if (new Date().getTime() - start > 100) {
            console.clear(); 
        }
    }, 500);

    let isGodMode = false;
    let fakeFullscreenElement = null;
    let config = { enableFs: true, enableCopy: true };
    let copyStyleTag = null;

    // --- 1. PRESERVE NATIVES ---
    const _req = Element.prototype.requestFullscreen;
    const _exit = document.exitFullscreen;

    // --- 2. LISTEN FOR ACTIVATION & UPDATES ---
    // This comes from content_loader.js (Isolated World)
    window.addEventListener("message", (e) => {
        if (e.data.type === "ACTIVATE_GOD_MODE") {
            // Update Config Dynamiclly
            if (e.data.config) {
                config = e.data.config;
            }

            if (!isGodMode) {
                console.log("🔓 Smart Block PRO: God Mode Activated");
                isGodMode = true;
                enforceOverrides();
            }
            
            // Always update CSS state on message (in case toggle changed)
            updateCopyCss();
        }
    });

    function updateCopyCss() {
        if (isGodMode && config.enableCopy) {
            if (!copyStyleTag) {
                copyStyleTag = document.createElement('style');
                copyStyleTag.innerHTML = `
                    /* Allow text selection generally, but EXCLUDE interactive elements */
                    *:not(button):not(a):not(input):not(textarea):not(select):not([role="button"]) {
                        -webkit-user-select: text !important;
                        -moz-user-select: text !important;
                        -ms-user-select: text !important;
                        user-select: text !important;
                    } 
                    /* Fix overlay blockers */
                    .nocopy, [oncopy] { 
                        -webkit-user-select: text !important; 
                        pointer-events: auto !important; 
                    }
                `;
                (document.head || document.documentElement).appendChild(copyStyleTag);
            }
        } else {
            if (copyStyleTag) {
                copyStyleTag.remove();
                copyStyleTag = null;
            }
        }
    }

    // --- 3. THE MOCKING ENGINE ---
    function enforceOverrides() {
        
        // A. FAKE REQUEST FULLSCREEN
        // We tell the site "Sure, we are going fullscreen", but we just set a variable.
        const fakeRequest = function() {
            // Only block if GodMode is active AND Fullscreen Blocker is enabled
            if (isGodMode && config.enableFs) {
                // console.log("🚫 Blocking Real Fullscreen -> Faking Success");
                fakeFullscreenElement = this; // 'this' is the element requesting it
                
                // Emit the event saying "We did it!"
                setTimeout(() => {
                    const evt = new Event("fullscreenchange", { bubbles: true, cancelable: false });
                    document.dispatchEvent(evt);
                    if(fakeFullscreenElement) fakeFullscreenElement.dispatchEvent(evt);
                }, 50);

                return Promise.resolve();
            }
            return _req.apply(this, arguments);
        };
        // Mask the function to look native (Anti-Tamper check)
        fakeRequest.toString = () => "function requestFullscreen() { [native code] }";
        
        Object.defineProperty(Element.prototype, "requestFullscreen", {
            value: fakeRequest,
            writable: true, configurable: true
        });
        
        // Handle vendor prefixes
        ['webkitRequestFullscreen', 'mozRequestFullScreen', 'msRequestFullscreen'].forEach(fn => {
            if (Element.prototype[fn]) {
                Object.defineProperty(Element.prototype, fn, {
                    value: fakeRequest, writable: true, configurable: true
                });
            }
        });

        // B. FAKE EXIT FULLSCREEN
        const fakeExit = function() {
            if (isGodMode && config.enableFs && fakeFullscreenElement) {
                fakeFullscreenElement = null;
                // Emit event
                setTimeout(() => {
                    const evt = new Event("fullscreenchange", { bubbles: true, cancelable: false });
                    document.dispatchEvent(evt);
                }, 50);
                return Promise.resolve();
            }
            return _exit.apply(this, arguments);
        };
        fakeExit.toString = () => "function exitFullscreen() { [native code] }";
        
        Object.defineProperty(document, "exitFullscreen", { value: fakeExit, writable: true, configurable: true });
        ['webkitExitFullscreen', 'mozCancelFullScreen', 'msExitFullscreen'].forEach(fn => {
             if (document[fn]) {
                Object.defineProperty(document, fn, { value: fakeExit, writable: true, configurable: true });
             }
        });

        // C. MOCK document.fullscreenElement
        // Sites check this to verify success. We return our fake element if blocking is active.
        Object.defineProperty(document, 'fullscreenElement', {
            get: () => (isGodMode && config.enableFs) ? fakeFullscreenElement : null,
            configurable: true
        });
        // Webkit version
        Object.defineProperty(document, 'webkitFullscreenElement', {
            get: () => (isGodMode && config.enableFs) ? fakeFullscreenElement : null,
            configurable: true
        });

        // D. COPY / PASTE / RIGHT CLICK LIBERATOR
        function killEvent(e) {
            e.stopImmediatePropagation();
            return true;
        }
        
        // KEPT: Events that specifically restrict copy/paste/context.
        const events = ['contextmenu', 'copy', 'cut', 'paste', 'selectstart', 'dragstart', 'visibilitychange', 'blur', 'focus'];
        
        events.forEach(evt => {
            window.addEventListener(evt, (e) => {
                // For visibility/focus, we want to TRICK the site into thinking it's always focused
                // For copy/paste, we only interfere if enabled
                if (isGodMode) {
                    // Always block visibility checks to prevent tab-switch detection
                    if (evt === 'visibilitychange' || evt === 'blur') {
                        e.stopImmediatePropagation();
                        return;
                    }
                    
                    // Only enforce Copy/Paste/Context unblocking if enabled
                    if (config.enableCopy) {
                         e.stopImmediatePropagation(); 
                    }
                }
            }, true); // Capture phase!
        });

        // Apply CSS initially
        updateCopyCss();

        // F. ALWAYS VISIBLE SPOOFING (Advanced)
        // Some sites check document.hidden or document.visibilityState
        // We generally leave this ON as it is a core protection against tracking
        Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
        Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
        
        console.log("✅ Smart Block: Fullscreen Mocked & Copy Freed.");
    }
})();
