
/**
 * ⛔ WARNING: PROPRIETARY CODE
 * Copyright (c) 2025 Smart Block Pro. All Rights Reserved.
 * * UNAUTHORIZED COPYING, REVERSE ENGINEERING, OR DISTRIBUTION 
 * OF THIS SOFTWARE IS STRICTLY PROHIBITED AND WILL BE PROSECUTED.
 * * This code contains digital watermarks that track unauthorized usage.
 * Tracking ID: SB-TRACK-UserLogin-Active
 */

// ANT-TAMPER PROTECTION
(function() {
    try {
        setInterval(() => {
            const start = new Date().getTime();
            debugger; // This stops the code if DevTools is open
            if (new Date().getTime() - start > 100) {
                 console.clear(); 
            }
        }, 500);

        // Prevent console printing of sensitive objects
        Object.defineProperty(window, "console", {
            value: { log: () => {}, warn: () => {}, error: () => {}, clear: () => {} },
            writable: false,
            configurable: false
        });
    } catch (e) {}
})();

import { AuthService } from './auth_service.js';
import { LicenseService } from './license_service.js';

document.addEventListener('DOMContentLoaded', async () => {
    // DISPLAY VERSION
    const appVer = document.getElementById('app-version');
    if(appVer) appVer.textContent = `v${chrome.runtime.getManifest().version}`;

    // MAIN VIEWS
    const vAuth = document.getElementById('view-auth');
    const vAct = document.getElementById('view-activate');
    const vDash = document.getElementById('view-dash');

    // SUB VIEWS (AUTH)
    const svLogin = document.getElementById('subview-login');
    const svRegister = document.getElementById('subview-register');
    const linkToReg = document.getElementById('link-to-register');
    const linkToLogin = document.getElementById('link-to-login');
    
    // LOGIN INPUTS
    const emailInp = document.getElementById('email');
    const passInp = document.getElementById('password');
    const authErr = document.getElementById('auth-error');
    const loadLogin = document.getElementById('load-login');
    const eyeLogin = document.getElementById('eye-login');

    // REGISTER INPUTS
    const regName = document.getElementById('reg-name');
    const regEmail = document.getElementById('reg-email');
    const regPass = document.getElementById('reg-password');
    const regConfirm = document.getElementById('reg-confirm');
    const eyeReg = document.getElementById('eye-reg');
    
    // ACTIVATION ELEMENTS
    const licKeyInp = document.getElementById('license-key');
    const actErr = document.getElementById('act-error');
    const loadAct = document.getElementById('load-act');
    const btnActivate = document.getElementById('btn-activate');

    // DASHBOARD ELEMENTS
    const userEmailSpan = document.getElementById('user-email');
    const licenseBadge = document.getElementById('license-badge');
    const licenseExpirySpan = document.getElementById('license-expiry');
    const adminNotesDiv = document.getElementById('admin-notes');
    const secAiTools = document.getElementById('sec-ai-tools');

    // TOGGLES
    const toggleFs = document.getElementById('toggle-fs');
    const toggleCopy = document.getElementById('toggle-copy');
    const toggleAi = document.getElementById('toggle-ai');

    // KEY MANAGER
    const btnToggleKeys = document.getElementById('btn-toggle-keys');
    const keyManagerDiv = document.getElementById('key-manager');
    const btnSaveKeys = document.getElementById('btn-save-keys');
    const keyInput = document.getElementById('api-key-input');

    // ==========================================
    // 0. AUTO-REDIRECT LOGIC (STRICT MODE)
    // ==========================================
    async function checkStatusAndRedirect() {
        // 1. Hide Everything / Reset UI
        if(vAuth) vAuth.classList.add('hide');
        if(vAct) vAct.classList.add('hide');
        if(vDash) vDash.classList.add('hide');

        const headerSub = document.querySelector('.header .sub');
        const orgSub = "Control Panel";
        if(headerSub) headerSub.textContent = "Verifying License...";

        try {
            const storage = await chrome.storage.local.get(['session', 'user', 'access_tier', 'license_notes', 'license_expiry', 'masterPower', 'copyMode', 'aiMode', 'geminiKey', 'update_url']);
            
            // 🛑 STOP: CHECK FOR UPDATE LOCK FIRST
            if (storage.access_tier === 'OUTDATED') {
                const downloadLink = storage.update_url || "https://discord.gg/s4FzeWNV";
                document.body.innerHTML = `
                    <style>
                        body { width: 340px; background: #0f172a; color: white; font-family: 'Segoe UI', sans-serif; padding: 20px; text-align: center; margin: 0; box-sizing: border-box; }
                        .card { background: #1e293b; padding: 30px; border-radius: 12px; border: 1px solid #3b82f6; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
                        h2 { color: #60a5fa; margin-top: 0; font-size: 18px; margin-bottom: 10px; }
                        p { color: #94a3b8; margin-bottom: 20px; font-size: 13px; line-height: 1.5; }
                        .btn { background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold; font-size: 13px; transition: 0.2s; }
                        .btn:hover { background: #1d4ed8; }
                    </style>
                    <div class="card">
                        <h2>⚠️ Update Required</h2>
                        <p>This version is no longer supported.<br>Please download the latest patch to continue.</p>
                        <a href="${downloadLink}" target="_blank" class="btn">Download Update</a>
                    </div>
                `;
                return; // Stop the rest of the code from loading
            }
            
            // A. NOT LOGGED IN -> Show Auth
            if (!storage.session || !storage.user) {
                if(headerSub) headerSub.textContent = orgSub;
                showAuth();
                return;
            }

            // B. CHECK SERVER (STRICT)
            let license = null;
            let dbError = false;

            try {
                // Fetch the actual license key row
                license = await LicenseService.fetchUserConfig(storage.user.id, storage.session);
            } catch (netErr) {
                console.warn("Network check failed:", netErr);
                dbError = true;
            }

            // C. DECISION LOGIC
            const now = new Date();
            let currentTier = 'NONE';
            
            // PRIORITY 1: Found a specific License
            if (license) {
                const expiry = new Date(license.expiry_date);
                if (expiry > now && license.status === 'ON') {
                    currentTier = license.type || 'PREMIUM';
                    
                    // Sync Local Cache
                    await chrome.storage.local.set({
                        active_license_key: license.key,
                        license_expiry: license.expiry_date,
                        access_tier: currentTier,
                        license_notes: license.notes || ""
                    });
                    storage.license_notes = license.notes; // Update local var for immediate display
                    storage.license_expiry = license.expiry_date;
                } else {
                    currentTier = 'NONE'; // Expired or Turned OFF by admin
                    // Explicitly clear bad credentials
                    await chrome.storage.local.remove(['access_tier', 'active_license_key', 'license_notes', 'license_expiry']);
                }
            } 
            // PRIORITY 2: No License Found in DB -> LOCKED
            else if (!dbError) {
                currentTier = 'NONE';
                await chrome.storage.local.remove(['access_tier', 'active_license_key', 'license_notes', 'license_expiry']);
            } 
            // PRIORITY 3: Network Error (Fail Safe / Offline Mode)
            else {
                // Only allow if we have a valid cache
                if (storage.access_tier && storage.access_tier !== 'NONE' && storage.active_license_key) {
                    currentTier = storage.access_tier;
                } else {
                    currentTier = 'NONE';
                }
            }
            
            // --- CLOUD KEY SYNC (Only if Authorized) ---
            if (currentTier !== 'NONE') {
                try {
                    const cloudKey = await LicenseService.fetchCloudKeys(storage.user.id, storage.session);
                    if(cloudKey) {
                        await chrome.storage.local.set({ geminiKey: cloudKey });
                        storage.geminiKey = cloudKey; 
                    }
                } catch(keyErr) {}
            }

            // Refresh storage object display vals
            storage.access_tier = currentTier;

            if(headerSub) headerSub.textContent = orgSub;

            // D. ROUTING
            if (currentTier === 'PREMIUM' || currentTier === 'STANDARD') {
                showDash(storage, currentTier);
            } else {
                // LOCKED OUT - MUST ENTER KEY
                showActivation();
            }

        } catch (e) {
            console.error("Critical Init Error:", e);
            if(headerSub) headerSub.textContent = orgSub;
            showAuth(); 
        }
    }

    // Call immediately on load
    await checkStatusAndRedirect();

    // ==========================================
    // 1. UI HELPERS
    // ==========================================
    
    // View Switcher
    function toggleAuthView(view) {
        if(authErr) authErr.classList.add('hide');
        if (view === 'REGISTER') {
            svLogin.classList.add('hide');
            svRegister.classList.remove('hide');
        } else {
            svRegister.classList.add('hide');
            svLogin.classList.remove('hide');
        }
    }

    if (linkToReg) linkToReg.onclick = () => toggleAuthView('REGISTER');
    if (linkToLogin) linkToLogin.onclick = () => toggleAuthView('LOGIN');

    // Password Eye Toggle
    function setupEye(eyeElem, inputElem) {
        if(!eyeElem || !inputElem) return;
        eyeElem.onclick = () => {
            const isPass = inputElem.type === 'password';
            inputElem.type = isPass ? 'text' : 'password';
            if(isPass) eyeElem.classList.add('active');
            else eyeElem.classList.remove('active');
        };
    }
    setupEye(eyeLogin, passInp);
    setupEye(eyeReg, regPass);

    function setLoading(isLoading, loaderElem) {
        if(!loaderElem) return;
        const btn = loaderElem.parentElement;
        const textSpan = btn.querySelector('span:not(.loader)');
        
        if(isLoading) {
            loaderElem.style.display = "block";
            if(textSpan) textSpan.style.display = "none";
            btn.disabled = true;
        } else {
            loaderElem.style.display = "none";
            if(textSpan) textSpan.style.display = "inline";
            btn.disabled = false;
        }
    }

    // FORGOT PASSWORD TOGGLE
    const forgotLink = document.getElementById('forgotPasswordLink');
    const messageBox = document.getElementById('contactMessage');

    if (forgotLink && messageBox) {
        forgotLink.addEventListener('click', function(e) {
            e.preventDefault(); // Stops the link from jumping the page
            
            // Toggle visibility (Show if hidden, hide if shown)
            if (messageBox.style.display === 'none') {
                messageBox.style.display = 'block';
            } else {
                messageBox.style.display = 'none';
            }
        });
    }

    // ==========================================
    // 2. VIEW RENDERERS
    // ==========================================

    function showAuth() {
        if(vAuth) vAuth.classList.remove('hide');
        if(vAct) vAct.classList.add('hide');
        if(vDash) vDash.classList.add('hide');
    }

    function showActivation() {
        if(vAuth) vAuth.classList.add('hide');
        if(vAct) vAct.classList.remove('hide');
        if(vDash) vDash.classList.add('hide');
    }

    function showDash(data, tier) {
        if(userEmailSpan) userEmailSpan.textContent = data.user.email;
        
        // DISPLAY EXPIRY
        if(licenseExpirySpan) {
            if(data.license_expiry) {
                const d = new Date(data.license_expiry);
                licenseExpirySpan.textContent = d.toLocaleDateString();
            } else {
                licenseExpirySpan.textContent = "Lifetime";
            }
        }
        
        // DISPLAY SUBSCRIPTION NOTES (Active Plan)
        if(adminNotesDiv) {
            if (data.license_notes) {
                adminNotesDiv.textContent = data.license_notes;
                adminNotesDiv.style.display = 'block';
                // Optional: Style it to look like a plan badge if needed
                adminNotesDiv.style.color = "#4ade80"; 
                adminNotesDiv.style.fontWeight = "600";
            } else if (tier === 'PREMIUM') {
                adminNotesDiv.textContent = "Active: Premium Plan";
                adminNotesDiv.style.display = 'block';
            } else {
                // If no notes and not premium fallback, hide it or empty it
                adminNotesDiv.style.display = 'none';
            }
        }
        
        // --- TOGGLE EVENT LISTENERS ---
        if(toggleFs) {
            toggleFs.checked = (data.masterPower !== false); 
            toggleFs.onchange = (e) => {
                chrome.storage.local.set({ masterPower: e.target.checked });
            };
        }
        if(toggleCopy) {
            toggleCopy.checked = (data.copyMode !== false);
            toggleCopy.onchange = (e) => {
                chrome.storage.local.set({ copyMode: e.target.checked });
            };
        }
        if(toggleAi) {
            toggleAi.checked = (data.aiMode !== false);
            toggleAi.onchange = (e) => {
                chrome.storage.local.set({ aiMode: e.target.checked });
            };
        }

        if (data.geminiKey && keyInput) {
            keyInput.value = data.geminiKey;
        }

        if (tier === 'STANDARD') {
            if(licenseBadge) {
                licenseBadge.textContent = "STANDARD";
                licenseBadge.className = "tag norm";
            }
            if(secAiTools) secAiTools.remove(); 
        } else if (tier === 'PREMIUM') {
            if(licenseBadge) {
                licenseBadge.textContent = "PREMIUM";
                licenseBadge.className = "tag pro";
            }
            if(secAiTools) secAiTools.classList.remove('hide');
        }

        if(vAuth) vAuth.classList.add('hide');
        if(vAct) vAct.classList.add('hide');
        if(vDash) vDash.classList.remove('hide');
    }

    // ==========================================
    // 3. ACTIONS
    // ==========================================

    if (btnToggleKeys) {
        btnToggleKeys.onclick = () => {
            if(keyManagerDiv) keyManagerDiv.classList.toggle('hide');
        };
    }

    if (btnSaveKeys) {
        btnSaveKeys.onclick = async () => {
            const originalText = btnSaveKeys.innerText;
            btnSaveKeys.innerText = "SAVING...";
            btnSaveKeys.disabled = true;

            const keyVal = keyInput.value.trim();

            // 1. SAVE TO CLOUD (Supabase) via RLS
            try {
                const storage = await chrome.storage.local.get(['user', 'session']);
                if (storage.user && storage.session) {
                    await LicenseService.saveCloudKeys(storage.user.id, storage.session, keyVal);
                }
            } catch(e) {
                console.warn("Cloud save warning:", e);
                // We continue to local save even if cloud fails (Offline mode)
            }

            // 2. SAVE LOCALLY
            chrome.storage.local.set({ geminiKey: keyVal }, () => {
                btnSaveKeys.innerText = "Key Saved Securely!";
                btnSaveKeys.style.background = "#22c55e";
                
                setTimeout(() => {
                    btnSaveKeys.innerText = originalText;
                    btnSaveKeys.style.background = ""; 
                    btnSaveKeys.disabled = false;
                    if(keyManagerDiv) keyManagerDiv.classList.add('hide');
                }, 1500);
            });
        };
    }

    // LOGIN
    if(document.getElementById('btn-login')) {
        document.getElementById('btn-login').onclick = async () => {
            setLoading(true, loadLogin);
            if(authErr) authErr.classList.add('hide');
            try {
                await AuthService.login(emailInp.value, passInp.value);
                // SUCCESS: Auto-Redirect check instead of hard reload
                await checkStatusAndRedirect();
            } catch (e) {
                // AUTO RESEND CONFIRMATION LOGIC
                const msg = e.message || "";
                if(authErr) {
                    if (msg.toLowerCase().includes("email not confirmed")) {
                        authErr.style.color = "#eab308";
                        authErr.textContent = "Email not confirmed. Sending new link...";
                        authErr.classList.remove('hide');
                        authErr.style.background = "rgba(234, 179, 8, 0.1)";

                        try {
                            await AuthService.resendConfirmationEmail(emailInp.value);
                            setTimeout(() => {
                                authErr.textContent = "New link sent! Check your inbox.";
                                authErr.style.color = "#22c55e"; 
                                authErr.style.background = "rgba(34, 197, 94, 0.1)";
                            }, 1000);
                        } catch (resendErr) {
                            authErr.textContent = "Failed to resend link. Please wait.";
                            authErr.style.color = "#ef4444";
                            authErr.style.background = "rgba(239, 68, 68, 0.1)";
                        }
                    } else {
                        authErr.style.color = "#ef4444";
                        authErr.style.background = "rgba(239, 68, 68, 0.1)";
                        authErr.textContent = e.message;
                        authErr.classList.remove('hide');
                    }
                }
            } finally {
                setLoading(false, loadLogin);
            }
        };
    }

    // SIGNUP
    if(document.getElementById('btn-signup')) {
        const btnSignup = document.getElementById('btn-signup');
        const loadReg = document.getElementById('load-reg');

        btnSignup.onclick = async () => {
            if(authErr) authErr.classList.add('hide');
            
            // 1. VALIDATION
            const name = regName.value.trim();
            const email = regEmail.value.trim();
            const pass = regPass.value;
            const confirm = regConfirm.value;

            if (!name || !email || !pass || !confirm) {
                authErr.textContent = "All fields are required.";
                authErr.style.color = "#ef4444";
                authErr.style.background = "rgba(239, 68, 68, 0.1)";
                authErr.classList.remove('hide');
                return;
            }

            if (pass !== confirm) {
                authErr.textContent = "Passwords do not match.";
                authErr.style.color = "#ef4444";
                authErr.style.background = "rgba(239, 68, 68, 0.1)";
                authErr.classList.remove('hide');
                return;
            }

            // 2. EXECUTION
            const originalText = btnSignup.querySelector('span:not(.loader)').innerText;
            btnSignup.querySelector('span:not(.loader)').innerText = "CREATING...";
            setLoading(true, loadReg);

            try {
                const data = await AuthService.signUp(email, pass, name);
                
                if(authErr) {
                    authErr.classList.remove('hide');
                    authErr.style.color = "#22c55e"; 
                    authErr.style.background = "rgba(34, 197, 94, 0.1)";
                    
                    if (data.session) {
                        authErr.textContent = "Success! Logging in...";
                        // Auto-Redirect check
                        await checkStatusAndRedirect();
                    } else {
                        // EXPLICIT SUCCESS MESSAGE
                        authErr.textContent = `Success! A confirmation link has been sent to ${email}.`;
                        // Switch back to Login view after delay
                        setTimeout(() => toggleAuthView('LOGIN'), 3000);
                    }
                }
            } catch (e) {
                if(authErr) {
                    authErr.style.color = "#ef4444";
                    authErr.style.background = "rgba(239, 68, 68, 0.1)";
                    authErr.textContent = e.message;
                    authErr.classList.remove('hide');
                }
            } finally {
                btnSignup.querySelector('span:not(.loader)').innerText = originalText;
                setLoading(false, loadReg);
            }
        };
    }

    // ACTIVATE
    if(btnActivate) {
        btnActivate.onclick = async () => {
            setLoading(true, loadAct);
            if(actErr) actErr.classList.add('hide');
            const originalText = btnActivate.querySelector('span:not(.loader)').textContent;
            btnActivate.querySelector('span:not(.loader)').textContent = "Verifying...";
            
            chrome.storage.local.get(['session', 'user'], async (s) => {
                if(!s.session) { location.reload(); return; }
                try {
                    await LicenseService.activateLicense(licKeyInp.value, s.user.email, s.user.id, s.session);
                    // Force refresh via our new function to update UI instantly
                    await checkStatusAndRedirect();
                } catch (e) {
                    if(actErr) {
                        actErr.textContent = e.message;
                        actErr.classList.remove('hide');
                    }
                    btnActivate.querySelector('span:not(.loader)').textContent = originalText;
                    setLoading(false, loadAct);
                }
            });
        };
    }

    // HELP TOGGLE
    const helpToggle = document.getElementById('help-toggle');
    if(helpToggle) {
        helpToggle.onclick = () => {
            if(helpToggle.innerText.indexOf('@') !== -1) {
                // Revert
                helpToggle.innerHTML = 'Need Help? Contact <span style="color: #60a5fa;">Support</span>';
                helpToggle.style.color = '#64748b';
                helpToggle.style.fontFamily = 'inherit';
            } else {
                // Show Email
                helpToggle.innerText = 'smart.block1@proton.me';
                helpToggle.style.color = '#e2e8f0';
                helpToggle.style.fontFamily = 'monospace';
            }
        }
    }

    // SCAN
    const btnScan = document.getElementById('btn-scan');
    if(btnScan) {
        btnScan.onclick = () => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if(tabs[0]) {
                    chrome.runtime.sendMessage({ type: "AI_SCAN_START", tabId: tabs[0].id });
                    window.close();
                }
            });
        };
    }

    // LOGOUT
    const logout = async () => {
        await AuthService.logout();
        location.reload();
    };
    if(document.getElementById('btn-logout-act')) document.getElementById('btn-logout-act').onclick = logout;
    if(document.getElementById('btn-logout-dash')) document.getElementById('btn-logout-dash').onclick = logout;
});
