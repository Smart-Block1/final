
const SUPABASE_URL = "https://akfwepxzzupenttuiaog.supabase.co";
const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFrZndlcHh6enVwZW50dHVpYW9nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjYxMTg4ODYsImV4cCI6MjA4MTY5NDg4Nn0.ZgofhCY5jU5jVsBEszWgzTina4bIxgpbaRM-jR7VHb0";

export const LicenseService = {
    async getProfileStatus(userId, token) {
        // LEGACY: We now rely on direct license table checks, but this can be used for UI labels if needed.
        try {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}&select=access_tier`, {
                method: 'GET',
                headers: { 
                    'apikey': ANON_KEY, 
                    'Authorization': `Bearer ${token}` 
                }
            });
            if (!res.ok) return 'NONE';
            
            const data = await res.json();
            return (data.length > 0 && data[0].access_tier) ? data[0].access_tier : 'NONE';
        } catch (e) {
            return 'NONE';
        }
    },

    async activateLicense(keyInput, userEmail, userId, token) {
        if (!token || !userId) throw new Error("Please log in to activate.");

        const cleanedKey = keyInput.trim();
        console.log("Activating Key:", cleanedKey, "for User:", userId);

        // 1. FETCH KEY DATA
        const searchUrl = `${SUPABASE_URL}/rest/v1/licenses?key=eq.${encodeURIComponent(cleanedKey)}&select=*`;
        const checkRes = await fetch(searchUrl, {
            method: 'GET',
            headers: { 
                'apikey': ANON_KEY, 
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        if (!checkRes.ok) throw new Error("Invalid License Key."); 
        
        const licenses = await checkRes.json();
        if (!licenses || licenses.length === 0) throw new Error("Invalid License Key.");
        
        const licenseData = licenses[0];

        // 3. CHECK: Is it already mine? (Auto-Restore)
        if (licenseData.owner === userId) {
            console.log("License restored.");
            // Force status to ON if it was somehow unset but owned
            if (licenseData.status !== 'ON') {
                await this._updateLicenseStatus(cleanedKey, 'ON', userId, token);
                licenseData.status = 'ON';
            }
            await this._saveLicenseLocally(licenseData);
            return { success: true, message: "Welcome back! License restored." };
        }

        // 4. CHECK: Is it stolen?
        if (licenseData.owner !== null) {
            throw new Error("This key is already used by another account.");
        }

        // 5. CLAIM IT
        // STRICT: We claim it by setting Owner and Status=ON
        const claimUrl = `${SUPABASE_URL}/rest/v1/licenses?key=eq.${encodeURIComponent(cleanedKey)}&owner=is.null`;
        
        const updateRes = await fetch(claimUrl, {
            method: 'PATCH',
            headers: { 
                'apikey': ANON_KEY, 
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation' 
            },
            body: JSON.stringify({ 
                status: 'ON', 
                owner: userId 
            })
        });

        let updatedRows = [];
        if (updateRes.ok) {
            updatedRows = await updateRes.json();
        }

        if (!updateRes.ok || !updatedRows || updatedRows.length === 0) {
            throw new Error("Activation failed. Key might have just been taken.");
        }

        console.log("Key claimed successfully!");
        
        // Also update Profile to MATCH THE LICENSE TYPE (STANDARD or PREMIUM)
        // Default to PREMIUM if type is missing to avoid breaking legacy keys
        const licenseTier = licenseData.type || 'PREMIUM';

        await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
            method: 'PATCH',
            headers: { 
                'apikey': ANON_KEY, 
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ access_tier: licenseTier })
        });
        
        // Save to local storage
        await this._saveLicenseLocally({ ...licenseData, owner: userId, status: 'ON' });

        return { success: true, message: "License Activated Successfully!" };
    },

    async _updateLicenseStatus(key, status, userId, token) {
        await fetch(`${SUPABASE_URL}/rest/v1/licenses?key=eq.${encodeURIComponent(key)}`, {
            method: 'PATCH',
            headers: { 
                'apikey': ANON_KEY, 
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: status })
        });
    },

    async _saveLicenseLocally(license) {
        const expiry = license.expiry_date || new Date(Date.now() + 31536000000).toISOString();
        const type = license.type || 'PREMIUM';
        
        await chrome.storage.local.set({
            active_license_key: license.key,
            license_expiry: expiry,
            access_tier: type
        });
    },

    async fetchUserConfig(userId, token) {
        // ROBUST FETCH: Get license owned by user AND status is ON.
        // This is the check that allows live revocation. If admin changes Status to OFF, this returns null.
        try {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/licenses?owner=eq.${userId}&status=eq.ON&order=expiry_date.desc&limit=1`, {
                method: 'GET',
                headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${token}` }
            });
            
            if (!res.ok) return null;
            
            const data = await res.json();
            return data.length > 0 ? data[0] : null;
        } catch(e) {
            console.warn("Fetch Config Error:", e);
            throw e;
        }
    },

    // ... Cloud key methods remain the same ...
    async fetchCloudKeys(userId, token) {
        try {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}&select=gemini_key_1,gemini_key_2,gemini_key_3,gemini_key_4`, {
                method: 'GET',
                headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${token}` }
            });
            if (!res.ok) return [];
            const data = await res.json();
            if (data && data.length > 0) {
                const row = data[0];
                const keys = [row.gemini_key_1, row.gemini_key_2, row.gemini_key_3, row.gemini_key_4].filter(k => k && k.trim() !== "");
                return keys;
            }
            return [];
        } catch (e) {
            return [];
        }
    },

    async saveCloudKeys(userId, token, keysArray) {
        const updateBody = {
            gemini_key_1: keysArray[0] || null,
            gemini_key_2: keysArray[1] || null,
            gemini_key_3: keysArray[2] || null,
            gemini_key_4: keysArray[3] || null
        };

        const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
            method: 'PATCH',
            headers: { 
                'apikey': ANON_KEY, 
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updateBody)
        });
        
        if (!res.ok) throw new Error("Failed to save keys to cloud.");
        return true;
    },

    async fetchLatestVersion() {
        try {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/app_settings?select=version,download_url&order=id.desc&limit=1`, {
                method: 'GET',
                headers: { 
                    'apikey': ANON_KEY, 
                    'Content-Type': 'application/json'
                }
            });
            if (!res.ok) return null;
            const data = await res.json();
            return (data.length > 0) ? data[0] : null;
        } catch (e) {
            return null;
        }
    }
};
