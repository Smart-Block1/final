
/**
 * 🔐 LICENSE SECURITY MODULE
 * This module handles the secure handshake between the Extension and Supabase.
 * 
 * NOTE: 
 * - Verification Logic is Enforced by Supabase RLS (Row Level Security).
 * - No private keys are validated locally (prevents tampering).
 * - API Keys are retrieved securely from the 'profiles' table.
 */

const SUPABASE_URL = "https://akfwepxzzupenttuiaog.supabase.co";
const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFrZndlcHh6enVwZW50dHVpYW9nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjYxMTg4ODYsImV4cCI6MjA4MTY5NDg4Nn0.ZgofhCY5jU5jVsBEszWgzTina4bIxgpbaRM-jR7VHb0";

export const LicenseService = {
    
    // --- 1. VERIFY STATUS (SECURE) ---
    async getProfileStatus(userId, token) {
        try {
            // Queries the DB. RLS ensures user can only see their own data.
            const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}&select=access_tier`, {
                method: 'GET',
                headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${token}` }
            });
            if (!res.ok) return 'NONE';
            const data = await res.json();
            return (data.length > 0 && data[0].access_tier) ? data[0].access_tier : 'NONE';
        } catch (e) { return 'NONE'; }
    },

    // --- 2. ACTIVATE KEY (TRANSACTIONAL) ---
    async activateLicense(keyInput, userEmail, userId, token) {
        if (!token || !userId) throw new Error("Authentication missing.");
        const cleanedKey = keyInput.trim();

        // Step A: Check if Key Exists (Public Read-Only check)
        const checkRes = await fetch(`${SUPABASE_URL}/rest/v1/licenses?key=eq.${encodeURIComponent(cleanedKey)}&select=*`, {
            method: 'GET',
            headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${token}` }
        });
        
        if (!checkRes.ok) throw new Error("Invalid Key.");
        const licenses = await checkRes.json();
        if (!licenses || licenses.length === 0) throw new Error("Invalid License Key.");
        
        const licenseData = licenses[0];

        // Step B: Claim Ownership (Protected by RLS Policy: 'UPDATE if owner is NULL')
        // If someone else claimed it 1ms ago, this request will fail or return 0 rows.
        if (licenseData.owner === null) {
            const claimRes = await fetch(`${SUPABASE_URL}/rest/v1/licenses?key=eq.${encodeURIComponent(cleanedKey)}&owner=is.null`, {
                method: 'PATCH',
                headers: { 
                    'apikey': ANON_KEY, 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation' 
                },
                body: JSON.stringify({ status: 'ON', owner: userId })
            });

            const claimed = await claimRes.json();
            if (!claimRes.ok || claimed.length === 0) {
                throw new Error("Activation Failed: Key already in use.");
            }
        } else if (licenseData.owner !== userId) {
            throw new Error("This key is bound to another user.");
        }

        // Step C: Update User Profile Access Tier
        const tier = licenseData.type || 'PREMIUM';
        await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
            method: 'PATCH',
            headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ access_tier: tier })
        });

        // Step D: Local Cache (For offline speed)
        await this._saveLocal(licenseData.key, tier);
        return { success: true };
    },

    // --- 3. FETCH CONFIG (SYNC) ---
    async fetchUserConfig(userId, token) {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/licenses?owner=eq.${userId}&status=eq.ON&order=expiry_date.desc&limit=1`, {
            method: 'GET',
            headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${token}` }
        });
        if (!res.ok) return null;
        const data = await res.json();
        return data.length > 0 ? data[0] : null;
    },

    // --- 4. SECURE VAULT (API KEYS) ---
    // Keys are stored in the 'profiles' table, restricted to the user via RLS.
    async fetchCloudKeys(userId, token) {
        try {
            const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}&select=gemini_key`, {
                method: 'GET',
                headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${token}` }
            });
            if (!res.ok) return "";
            const data = await res.json();
            return (data && data.length > 0) ? (data[0].gemini_key || "") : "";
        } catch (e) { return ""; }
    },

    async saveCloudKeys(userId, token, keyString) {
        await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
            method: 'PATCH',
            headers: { 'apikey': ANON_KEY, 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ gemini_key: keyString })
        });
        return true;
    },

    async _saveLocal(key, tier) {
        await chrome.storage.local.set({
            active_license_key: key,
            access_tier: tier,
            license_expiry: new Date(Date.now() + 31536000000).toISOString()
        });
    }
};
