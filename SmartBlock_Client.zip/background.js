
// background.js - Clean Secure Version

import { AuthService } from './auth_service.js';

// Listen for installation
chrome.runtime.onInstalled.addListener(() => {
    console.log("Smart Block Pro: Installed & Ready (Secure Mode)");
});

// Listen for messages from Popup or Content Scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // Check if user is logged in
    if (request.type === "CHECK_AUTH") {
        AuthService.getSession().then(session => {
            sendResponse({ session: session });
        });
        return true; // Important for async response
    }

    // Add other listeners here if needed
});
